from scripts.eval.configs.seer_on_calvin import eval_cfg
from grmanipulation.agent.utils import PolicyServer


def main():
    server = PolicyServer(eval_cfg.agent.server_cfg)
    server.run()

if __name__ == "__main__":
    main()