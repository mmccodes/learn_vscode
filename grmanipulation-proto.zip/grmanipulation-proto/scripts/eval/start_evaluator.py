from grmanipulation.evaluator import Evaluator
import argparse
import importlib.util
import sys

def load_eval_cfg(config_path):
    spec = importlib.util.spec_from_file_location("eval_config_module", config_path)
    config_module = importlib.util.module_from_spec(spec)
    sys.modules["eval_config_module"] = config_module
    spec.loader.exec_module(config_module)
    return getattr(config_module, "eval_cfg")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config",
        type=str,
        required=True,
        help="eval config file path, e.g. scripts/eval/configs/openvla_on_simpler.py"
    )
    args = parser.parse_args()

    eval_cfg = load_eval_cfg(args.config)
    evaluator = Evaluator.init(eval_cfg)
    evaluator.eval()

if __name__ == "__main__":
    main()