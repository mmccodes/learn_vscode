from grmanipulation.configs import *
import os
from pathlib import Path


eval_cfg = EvalCfg(
    eval_type="simpler",
    agent=AgentCfg(
        agent_type="openvla",
        model_cfg=ModelCfg(
            model_type="openvla",
            policy_name="openvla",
            ckpt_path=os.path.expanduser("~/.cache/huggingface/hub/models--openvla--openvla-7b"),
            model_settings={
                "saved_model_path": "openvla/openvla-7b",
                "unnorm_key": None,
                "policy_setup": "google_robot",
                "horizon": 1,
                "pred_action_horizon": 1,
                "exec_horizon": 1,
                "image_size": [224, 224],
                "action_scale": 1.0,
            },
        ),
        server_cfg=ServerCfg(
            server_host="localhost",
            server_port=5000,
            device="cuda",
        ),
    ),
    env=EnvCfg(
        env_type="simpler",
        env_settings={
            "policy_setup": "google_robot",
            "task_name": "google_robot_pick_coke_can",
            "robot": "google_robot_static",
            "control_freq": 3,
            "sim_freq": 513,
            "max_episode_steps": 80,
            "rgb_overlay_path": "/ssd/tianshihan/grmanipulation/grmanipulation/benchmarks/SimplerEnv/ManiSkill2_real2sim/data/real_inpainting/google_coke_can_real_eval_1.png",
            "robot_init_x_range": (0.35, 0.35, 1.0),
            "robot_init_y_range": (0.20, 0.20, 1.0),
            "robot_init_rot_quat_center": (0.0, 0.0, 0.0, 1.0),
            "robot_init_rot_rpy_range": (0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0),
            "obj_init_x_range": (-0.35, -0.12, 5),
            "obj_init_y_range": (-0.02, 0.42, 5),
            "additional_env_build_kwargs": {
                "lr_switch": True, 
                "upright": True, 
                "laid_vertically": True
            }
        },
    ),
    eval_settings={
        "logging_dir": "/ssd/tianshihan/grmanipulation/logs/eval/simpler"
    },
)