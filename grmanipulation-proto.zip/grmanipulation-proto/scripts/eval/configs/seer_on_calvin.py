from grmanipulation.configs import *
from pathlib import Path
import os


eval_cfg = EvalCfg(
    eval_type="calvin",
    agent=AgentCfg(
        agent_type="seer",
        model_cfg=ModelCfg(
            model_type="seer",
            policy_name="seer",
            ckpt_path=os.path.expanduser("~/Downloads/19.pth"),
            model_settings={
                "traj_cons": True,
                "rgb_pad": 10,
                "gripper_pad": 4,
                "gradient_accumulation_steps": 1,
                "bf16_module": "vision_encoder",
                "vit_checkpoint_path": os.path.expanduser("~/Downloads/mae_pretrain_vit_base.pth"),
                "workers": 16,
                "lr_scheduler": "cosine",
                "save_every_iter": 50000,
                "num_epochs": 20,
                "seed": 42,
                "batch_size": 64,
                "precision": "fp32",
                "weight_decay": 1e-4,
                "num_resampler_query": 6,
                "num_obs_token_per_image": 9,
                "run_name": "vit_mae",
                "transformer_layers": 24,
                "hidden_dim": 384,
                "transformer_heads": 12,
                "phase": "evaluate",
                "finetune_type": "calvin",
                "action_pred_steps": 3,
                "sequence_length": 10,
                "future_steps": 3,
                "window_size": 13,
                "obs_pred": True,
                "resume_from_checkpoint": os.path.expanduser("~/Downloads/19.pth"),
                "use_multi_gpu": False,
                "device_ids": None,
            },
        ),
        server_cfg=ServerCfg(
            server_host="localhost",
            server_port=5000,
            device="cuda",
        ),
    ),
    env=EnvCfg(
        env_type="calvin",
        env_settings={
            "config_path": f"{Path(__file__).absolute().parents[3]}/grmanipulation/benchmarks/utils/calvin/merged_config.yaml",
        }
    ),
    eval_settings={
        "logging_dir": f"/ssd/tianshihan/grmanipulation/logs/eval/calvin",
    },
)