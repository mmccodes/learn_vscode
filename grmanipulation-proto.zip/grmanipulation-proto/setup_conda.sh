# Choose conda env name
echo "The new conda environment will be named 'grmanipulation' by default."
read -p "If you want to use a different name, please type in here (press enter to skip) >>> " conda_name
conda_name=${conda_name:-grmanipulation}
echo -e "\nUsing '$conda_name' as the conda environment name\n"

# Create a conda environment
source $(conda info --base)/etc/profile.d/conda.sh
conda create -y -n $conda_name python=3.10
conda activate $conda_name

# Install dependencies for evaluation benchmarks
# 1. calvin dependencies
export CALVIN_ROOT=grmanipulation/benchmarks/calvin

cd $CALVIN_ROOT
sh install.sh

# 2. simpler dependencies
cd ../SimplerEnv/ManiSkill2_real2sim
pip install -e .

cd ..
pip install -e .
pip install -r requirements_full_install.txt

# 3. grmanipulation dependencies
cd ../../..
pip install -e .

conda deactivate

echo -e "\n\n GrManipulation is now ready to use! Please run 'conda activate $conda_name' to activate the environment.\n\n"