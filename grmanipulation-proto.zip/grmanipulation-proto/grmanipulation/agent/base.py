from typing import Dict, Any
from grmanipulation.configs import AgentCfg

class BaseAgent:
    agents = {}
    
    def __init__(self, config: AgentCfg):
        self.config = config

    def step(self):
        pass

    def reset(self):
        pass

    @classmethod
    def register(cls, agent_type: str):
        """
        Register a agent class.
        """
        def decorator(agent_class):
            cls.agents[agent_type] = agent_class

        return decorator
    
    @classmethod
    def init(cls, config: AgentCfg):
        """
        Init a agent instance from a config.
        """
        return cls.agents[config.agent_type](config)