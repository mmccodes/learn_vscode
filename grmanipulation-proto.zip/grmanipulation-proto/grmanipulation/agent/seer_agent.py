from typing import Dict, Any
import torch
import clip
import numpy as np
import functools
import base64
from collections import deque
import PIL.Image as Image
from grmanipulation.agent.base import BaseAgent
from grmanipulation.configs import AgentCfg
from grmanipulation.model.seer.seer_model import SeerModel
from grmanipulation.model.seer.utils.data_utils import preprocess_image, preprocess_text_calvin
from grmanipulation.model.seer.utils.train_utils import get_cast_dtype
import torch
import numpy as np
import random


def random_seed(seed=42, rank=0):
    torch.manual_seed(seed + rank)
    np.random.seed(seed + rank)
    random.seed(seed + rank)


@BaseAgent.register("seer")
class SeerAgent(BaseAgent):
    def __init__(self, config: AgentCfg):
        super().__init__(config)
        model_settings = config.model_cfg.model_settings

        random_seed(42)

        self.policy_model = SeerModel(
            finetune_type=model_settings.get("finetune_type", "default"),
            clip_device=model_settings.get("device", "cpu"),
            vit_checkpoint_path=model_settings.get("vit_checkpoint_path", ""),
            sequence_length=model_settings.get("sequence_length", 10),
            num_resampler_query=model_settings.get("num_resampler_query", 6),
            num_obs_token_per_image=model_settings.get("num_obs_token_per_image", 9),
            action_pred_steps=model_settings.get("action_pred_steps", 3),
            obs_pred=model_settings.get("obs_pred", False),
            atten_only_obs=model_settings.get("atten_only_obs", False),
            attn_robot_proprio_state=model_settings.get("attn_robot_proprio_state", False),
            atten_goal=model_settings.get("atten_goal", False),
            atten_goal_state=model_settings.get("atten_goal_state", False),
            mask_l_obs_ratio=model_settings.get("mask_l_obs_ratio", 0.0),
            calvin_input_image_size=model_settings.get("calvin_input_image_size", 224),
            patch_size=model_settings.get("patch_size", 16),
            mask_ratio=model_settings.get("mask_ratio", 0.0),
            transformer_layers=model_settings.get("transformer_layers", 24),
            hidden_dim=model_settings.get("hidden_dim", 384),
            transformer_heads=model_settings.get("transformer_heads", 12),
            phase=model_settings.get("phase", "evaluate"),
            gripper_width=model_settings.get("gripper_width", False),
        )

        # Set up single-machine multi-GPU training
        use_multi_gpu = model_settings.get("use_multi_gpu", False)
        device_ids = model_settings.get("device_ids", None)
        
        self.policy_model = self.policy_model.float()
        self.policy_model.vision_encoder.bfloat16()
        self.policy_model.clip_model.requires_grad_(False)
        self.policy_model.vision_encoder.requires_grad_(False)
        self.policy_model = self.policy_model.to('cuda:0')
        self.policy_model._init_model_type()

        # multi-GPU support
        if use_multi_gpu and torch.cuda.device_count() > 1:
            gpu_count = torch.cuda.device_count() if device_ids is None else len(device_ids)
            print(f"Running on {gpu_count} GPUs")
            self.policy_model = torch.nn.DataParallel(self.policy_model, device_ids=device_ids)
        else:
            print("Running on single GPU")
        
        if model_settings.get("resume_from_checkpoint") is not None:
            a = model_settings.get("resume_from_checkpoint")
            print(f"Loading checkpoint from {a}")
            checkpoint = torch.load(model_settings.get("resume_from_checkpoint"), map_location="cpu")

            # 去除参数名中的 "module." 前缀
            new_state_dict = {}
            for k, v in checkpoint["model_state_dict"].items():
                if k.startswith("module."):
                    name = k.replace("module.", "", 1)  # 仅移除第一个 "module." 前缀
                else:
                    name = k
                new_state_dict[name] = v
            
            self.policy_model.load_state_dict(new_state_dict, False)

        self.policy_model.eval()
        
        self.use_diff = False
        self.tokenizer = model_settings.get("tokenizer", clip)
        self.text_process_fn = functools.partial(preprocess_text_calvin, tokenizer=self.tokenizer)
        self.image_processor = self.policy_model.module.image_processor if use_multi_gpu and torch.cuda.device_count() > 1 else self.policy_model.image_processor
        self.image_process_fn = functools.partial(preprocess_image, image_processor=self.image_processor)
        self.cast_type = get_cast_dtype(model_settings.get("cast_type", "float32"))
        self.history_len = model_settings.get("sequence_length", 10)
        self.action_hist_queue = []
        self.calvin_eval_max_steps = model_settings.get("calvin_eval_max_steps", 360)
        self.action_pred_steps = model_settings.get("action_pred_steps", 3)
        self.device = "cuda"
        self.img_queue = deque(maxlen=self.history_len)
        self.gripper_queue = deque(maxlen=self.history_len)
        self.state_queue = deque(maxlen=self.history_len)
        self.mask_queue = deque(maxlen=self.history_len)
        self.text_queue = deque(maxlen=self.history_len)
        self.act_queue = deque(maxlen=self.history_len-1)
        self.is_data_parallel = isinstance(self.policy_model, torch.nn.DataParallel)

    def step(self, request: Dict[str, Any]):
        obs = request["observation"]
        goal = request["goal"]
        timestep = request["timestep"]

        image = obs["rgb_obs"]['rgb_static']
        image = Image.fromarray(image)
        image_x = self.image_process_fn([image])
        image_x = image_x.unsqueeze(1).to(dtype=self.cast_type)

        gripper = obs["rgb_obs"]['rgb_gripper']
        gripper = Image.fromarray(gripper)
        gripper = self.image_process_fn([gripper])
        gripper = gripper.unsqueeze(1).to(dtype=self.cast_type)

        text_x = self.text_process_fn([goal])
        text_x = text_x.unsqueeze(1)

        state = obs['robot_obs']
        state = torch.from_numpy(np.stack([state]))
        state = state.unsqueeze(1).to(dtype=self.cast_type)
        state = torch.cat([state[..., :6], state[..., [-1]]], dim=-1)

        with torch.no_grad():
            device = 'cuda'
            image_x = image_x.to(device)
            text_x = text_x.to(device)
            gripper = gripper.to(device)
            state = state.to(device)
            self.img_queue.append(image_x)  
            self.gripper_queue.append(gripper)
            self.state_queue.append(state)
            if len(self.text_queue) == 0 and text_x is not None:  
                self.text_queue.append(text_x)
                seq_length = self.policy_model.module.sequence_length if self.is_data_parallel else self.policy_model.sequence_length
                for _ in range(seq_length - 1):
                    self.text_queue.append(text_x)
            image_primary = torch.cat(list(self.img_queue), dim=1)
            image_wrist = torch.cat(list(self.gripper_queue), dim=1)
            state = torch.cat(list(self.state_queue), dim=1)
            input_text_token = torch.cat(list(self.text_queue), dim=1)
            num_step = image_primary.shape[1]
            if num_step < self.history_len:  
                input_image_primary = torch.cat([image_primary, image_primary[:, -1].repeat(1, self.history_len-num_step, 1, 1, 1)], dim=1)
                input_image_wrist = torch.cat([image_wrist, image_wrist[:, -1].repeat(1, self.history_len-num_step, 1, 1, 1)], dim=1)
                input_state = torch.cat([state, state[:, -1].repeat(1, self.history_len-num_step, 1)], dim=1)
            else:
                input_image_primary = image_primary
                input_image_wrist = image_wrist
                input_state = state
            arm_action, gripper_action, image_pred, arm_pred_state, gripper_pred_state, _ = self.policy_model(
                image_primary=input_image_primary,
                image_wrist=input_image_wrist,
                state=input_state,
                text_token=input_text_token,
                action=torch.zeros(1, self.history_len, 7).to(input_state.device),
            )
            action = torch.concat((arm_action[0, :, 0, :], gripper_action[0, :, 0, :] > 0.5), dim=-1)
            action[:, -1] = (action[:, -1] - 0.5) * 2  # scale to -1 or 1
            action = action.cpu().detach().to(dtype=torch.float16).numpy()
            if num_step < self.history_len:
                action = action[num_step - 1]
            else:
                action = action[-1]

        return action

    def reset(self):
        self.img_queue = deque(maxlen=self.history_len)
        self.gripper_queue = deque(maxlen=self.history_len)
        self.state_queue = deque(maxlen=self.history_len)
        self.mask_queue = deque(maxlen=self.history_len)
        self.text_queue = deque(maxlen=self.history_len)
        self.act_queue = deque(maxlen=self.history_len-1)