#!/usr/bin/env python
from typing import Dict, Any
import uvicorn
from fastapi import FastAPI, HTTPException, status, APIRouter
from grmanipulation.configs import ServerCfg
from grmanipulation.model.policymodel.base import BasePolicyModel
from grmanipulation.agent.utils.request_data import InitRequest


def to_device(data: Dict[str, Any], device: str) -> Dict[str, Any]:
    """
    Convert data to the specified device.
    """
    # This is a placeholder function. Implement the actual logic as needed.
    return data

class PolicyServer:
    """
    Server class for Policy service.
    """
    def __init__(self, config: ServerCfg):
        self.host = config.server_host
        self.port = config.server_port
        self.device = config.device
        self.app = FastAPI(title="Policy Service")
        self.policy_instances: Dict[str, BasePolicyModel] = {}
        
        self._router = APIRouter(prefix="/policy")
        self._register_routes()
        self.app.include_router(self._router)

    def _register_routes(self):
        route_config = [
            ("/init", self.init_policy, ["POST"], status.HTTP_201_CREATED),
            ("/{policy_name}/forward", self.policy_forward, ["POST"], None)
        ]

        for path, handler, methods, status_code in route_config:
            self._router.add_api_route(
                path=path,
                endpoint=handler,
                methods=methods,
                status_code=status_code
            )

    async def init_policy(self, request: InitRequest):
        policy_config = request.policy_cfg
        policy = BasePolicyModel.init(policy_config).to(self.device)
        policy_name = policy_config.policy_name
        self.policy_instances[policy_name] = policy
        return {"status": "success", "policy_name": policy_name}

    async def policy_forward(self, policy_name: str, request: Dict):
        self._validate_policy_exists(policy_name)
        policy = self.policy_instances[policy_name]

        args, kwargs = request.get("args", []), request.get("kwargs", {})
        args = to_device(args, self.device)
        kwargs = to_device(kwargs, self.device)
        output = policy(args, **kwargs)
        
        return output
    

    def _validate_policy_exists(self, policy_name: str):
        if policy_name not in self.policy_instances:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Policy not found"
            )

    def run(self):
        uvicorn.run(self.app, host=self.host, port=self.port)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--host', type=str, default='localhost')
    parser.add_argument('--port', type=int, default=5010)
    args = parser.parse_args()

    server_cfg = ServerCfg(server_host=args.host, server_port=args.port)

    server = PolicyServer(server_cfg)

    server.run()