from pydantic import BaseModel
from grmanipulation.configs import ModelCfg


class InitRequest(BaseModel):
    policy_cfg: ModelCfg
