import requests
from typing import Dict, Any
from grmanipulation.configs import AgentCfg


class PolicyClient:
    """
    Client class for Policy service.
    """
    
    def __init__(self, config: AgentCfg):
        self.base_url = f"http://{config.server_cfg.server_host}:{config.server_cfg.server_port}"
        self.policy_name = config.model_cfg.model_type

    def forward(self, args, **kwargs):
        request_data = {
            "args": args,
            "kwargs": kwargs
        }

        response = requests.post(
            url=f"{self.base_url}/policy/{self.policy_name}/forward",
            json=request_data,
            headers={"Content-Type": "application/json"}
        )
        response.raise_for_status()

        return response.json()
    
    def __call__(self, args: Dict[str, Any], **kwargs):
        return self.forward(args, **kwargs)