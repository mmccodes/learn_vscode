from grmanipulation.evaluator.base import Evaluator
from grmanipulation.configs import EvalCfg
from simpler_env.utils.env.observation_utils import get_image_from_maniskill2_obs_dict
from simpler_env.utils.visualization import write_video
from typing import Optional, Dict, Any
import os
from transforms3d.euler import quat2euler
import numpy as np


@Evaluator.register("simpler")
class SimplerEvaluator(Evaluator):
    def __init__(self, config: EvalCfg):
        super().__init__(config)

    def eval(self):
        success_arr = []

        # run inference
        for robot_init_x in self.env.robot_init_xs:
            for robot_init_y in self.env.robot_init_ys:
                for robot_init_quat in self.env.robot_init_quats:
                    episode_kwargs = dict(
                        robot_name=self.env.env_settings.robot,
                        task_name=self.env.env_settings.task_name,
                        env_name=self.env.env_settings.env_name,
                        scene_name=self.env.env_settings.scene_name,
                        robot_init_x=robot_init_x,
                        robot_init_y=robot_init_y,
                        robot_init_quat=robot_init_quat,
                        control_mode=self.env.control_mode,
                        additional_env_build_kwargs=self.env.env_settings.additional_env_build_kwargs,
                        rgb_overlay_path=self.env.env_settings.rgb_overlay_path,
                        control_freq=self.env.env_settings.control_freq,
                        sim_freq=self.env.env_settings.sim_freq,
                        max_episode_steps=self.env.env_settings.max_episode_steps,
                        enable_raytracing=self.env.env_settings.enable_raytracing,
                        additional_env_save_tags=self.env.env_settings.additional_env_save_tags,
                        obs_camera_name=self.env.env_settings.obs_camera_name
                    )

                    if self.env.env_settings.obj_variation_mode == "xy":
                        for obj_init_x in self.env.obj_init_xs:
                            for obj_init_y in self.env.obj_init_ys:
                                episode_kwargs["obj_init_x"] = obj_init_x
                                episode_kwargs["obj_init_y"] = obj_init_y
                                success_arr.append(self.eval_single_episode(episode_kwargs))
                    elif self.env.env_settings.obj_variation_mode == "episode":
                        for obj_episode_id in range(self.env.env_settings.obj_episode_range[0], self.env.env_settings.obj_episode_range[1]):
                            episode_kwargs["obj_episode_id"] = obj_episode_id
                            success_arr.append(self.eval_single_episode(episode_kwargs))
                    else:
                        raise NotImplementedError()
        
        print(f"+++++++++ Average success rate: {np.mean(success_arr)}")
    
    def eval_single_episode(self, episode_kwargs: Dict[str, Any], episode_i: Optional[int] = None):
        obs = self.env.reset(options=episode_kwargs)
        # for long-horizon environments, we check if the current subtask is the final subtask
        is_final_subtask = self.env.is_final_subtask()

        # get default language instruction
        task_description = self.env.get_language_instruction()
        print(task_description)

        # Initialize logging
        image = get_image_from_maniskill2_obs_dict(self.env, obs, camera_name=self.env.env_settings.obs_camera_name)
        images = [image]
        predicted_actions = []
        predicted_terminated, done, truncated = False, False, False

        # Initialize model
        self.agent.reset(task_description)

        timestep = 0
        success = "failure"

        # Step the environment
        while not (predicted_terminated or truncated):
            # step the model; "raw_action" is raw model action output; "action" is the processed action to be sent into maniskill env
            raw_action, action = self.agent.step(image, task_description)
            predicted_actions.append(raw_action)
            predicted_terminated = bool(action["terminate_episode"][0] > 0)
            if predicted_terminated:
                if not is_final_subtask:
                    # advance the environment to the next subtask
                    predicted_terminated = False
                    self.env.advance_to_next_subtask()

            # step the environment
            action = np.concatenate([action["world_vector"], action["rot_axangle"], action["gripper"]])
            obs, reward, done, truncated, info = self.env.step(action)
            
            success = "success" if done else "failure"
            new_task_description = self.env.get_language_instruction()
            if new_task_description != task_description:
                task_description = new_task_description
                print(task_description)
            is_final_subtask = self.env.is_final_subtask()

            print(timestep, info)

            image = get_image_from_maniskill2_obs_dict(self.env, obs, camera_name=self.env.env_settings.obs_camera_name)
            images.append(image)
            timestep += 1

        episode_stats = info.get("episode_stats", {})

        # save video
        env_save_name = episode_kwargs["env_name"]
        for k, v in episode_kwargs["additional_env_build_kwargs"].items():
            env_save_name = env_save_name + f"_{k}_{v}"
        if episode_kwargs["additional_env_save_tags"] is not None:
            env_save_name = env_save_name + f"_{episode_kwargs['additional_env_save_tags']}"
        ckpt_path_basename = self.config.agent.model_cfg.ckpt_path if self.config.agent.model_cfg.ckpt_path[-1] != "/" else self.config.agent.model_cfg.ckpt_path[:-1]
        ckpt_path_basename = ckpt_path_basename.split("/")[-1]
        if self.env.env_settings.obj_variation_mode == "xy":
            video_name = f"{success}_obj_{episode_kwargs['obj_init_x']}_{episode_kwargs['obj_init_y']}"
        elif self.env.env_settings.obj_variation_mode == "episode":
            video_name = f"{success}_obj_episode_{episode_kwargs['obj_episode_id']}"
        for k, v in episode_stats.items():
            video_name = video_name + f"_{k}_{v}"
        video_name = video_name + ".mp4"
        if episode_kwargs["rgb_overlay_path"] is not None:
            rgb_overlay_path_str = os.path.splitext(os.path.basename(episode_kwargs["rgb_overlay_path"]))[0]
        else:
            rgb_overlay_path_str = "None"
        r, p, y = quat2euler(episode_kwargs["robot_init_quat"])
        video_path = f"{ckpt_path_basename}/{episode_kwargs['scene_name']}/{episode_kwargs['control_mode']}/{env_save_name}/rob_{episode_kwargs['robot_init_x']}_{episode_kwargs['robot_init_y']}_rot_{r:.3f}_{p:.3f}_{y:.3f}_rgb_overlay_{rgb_overlay_path_str}/{video_name}"
        video_path = os.path.join(self.config.eval_settings["logging_dir"], video_path)
        write_video(video_path, images, fps=5)

        # save action trajectory
        action_path = video_path.replace(".mp4", ".png")
        action_root = os.path.dirname(action_path) + "/actions/"
        os.makedirs(action_root, exist_ok=True)
        action_path = action_root + os.path.basename(action_path)
        self.agent.visualize_epoch(predicted_actions, images, save_path=action_path)

        return success == "success"