from grmanipulation.configs.evaluator.eval_cfg import EvalCfg
from grmanipulation.agent import BaseAgent
from grmanipulation.env import EnvWrapper

class Evaluator:
    """
    Base class of all evaluators.
    """

    evaluators = {}

    def __init__(self, config: EvalCfg):
        self.config = config
        self.env = EnvWrapper.init(config.env)
        self.agent = BaseAgent.init(config.agent)

    def eval(self):
        raise NotImplementedError

    @classmethod
    def register(cls, evaluator_type: str):
        """
        Register a evaluator class.
        """
        def decorator(evaluator_class):
            cls.evaluators[evaluator_type] = evaluator_class

        return decorator
    
    @classmethod
    def init(cls, config: EvalCfg):
        """
        Init a evaluator instance from a config.
        """
        return cls.evaluators[config.eval_type](config)
