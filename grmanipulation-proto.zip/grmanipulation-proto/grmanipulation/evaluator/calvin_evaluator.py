from grmanipulation.evaluator.base import Evaluator
from grmanipulation.configs.evaluator.eval_cfg import EvalCfg
from collections import defaultdict
import logging
import os, json
from pathlib import Path
from calvin_agent.evaluation.utils import (
    collect_plan,
    count_success,
    get_env_state_for_initial_condition,
    get_log_dir,
    print_and_save,
)
import hydra
import numpy as np
from omegaconf import OmegaConf
from tqdm.auto import tqdm
import base64
from typing import Dict, Any


os.environ['PYOPENGL_PLATFORM'] = 'egl'
logger = logging.getLogger(__name__)


@Evaluator.register("calvin")
class CalvinEvaluator(Evaluator):
    def __init__(self, config: EvalCfg):
        super().__init__(config)
        # task oracle
        conf_dir = f"{Path(__file__).absolute().parents[1]}/benchmarks/calvin/calvin_models/conf"
        task_cfg = OmegaConf.load(Path(conf_dir) / "callbacks/rollout/tasks/new_playtable_tasks.yaml")
        self.task_oracle = hydra.utils.instantiate(task_cfg)
        # val annotations
        if self.env.env_settings.diverse_inst:
            with open(f"{Path(__file__).absolute().parents[1]}/benchmarks/utils/calvin/lang_annotation_cache.json", 'r') as f:
                self.val_annotations = json.load(f)
        else:
            self.val_annotations = OmegaConf.load(Path(conf_dir) / "annotations/new_playtable_validation.yaml")
        # eval log dir
        self.eval_log_dir = get_log_dir(self.config.eval_settings.get("logging_dir", "./logs/calvin/evaluation"))
        # episode length
        self.episode_length = self.env.env_settings.episode_length
        # num sequences
        self.num_sequences = self.env.env_settings.num_sequences
        # eval sequences
        with open(f"{Path(__file__).absolute().parents[1]}/benchmarks/utils/calvin/eval_sequences.json", 'r') as f:
            self.eval_sequences = json.load(f)
        self.eval_sequences = self.eval_sequences[:self.num_sequences]
        if not self.env.env_settings.debug:
            self.eval_sequences = tqdm(self.eval_sequences, position=0, leave=True)
        # results
        self.results = []
        # plans
        self.plans = defaultdict(list)

    def eval(self):
        """
        The entrypoint of the evaluation pipeline.
        """
        for sequence_i, evaluate_sequence in enumerate(self.eval_sequences):
            result = self.eval_single_episode(sequence_i, evaluate_sequence)
            self.results.append(result)
            self.eval_sequences.set_description(
                " ".join([f"{i + 1}/5 : {v * 100:.1f}% |" for i, v in enumerate(count_success(self.results))]) + "|"
            )
        print_and_save(self.results, self.eval_sequences, self.eval_log_dir, None)
    
    def eval_single_episode(self, episode_i, episode_data):
        """
        Evaluate the policy for one episode. It contains multiple subtasks(a sequence of natural language instructions).
        """
        initial_state, eval_sequence = episode_data[0], episode_data[1]
        robot_obs, scene_obs = get_env_state_for_initial_condition(initial_state)
        self.env.reset(options={"robot_obs": robot_obs, "scene_obs": scene_obs})
        success_counter = 0

        for subtask_i, subtask in enumerate(eval_sequence):
            if self.env.env_settings.reset:
                success = self.rollout(subtask, subtask_i, episode_i, robot_obs=robot_obs, scene_obs=scene_obs)
            else:
                success = self.rollout(subtask, subtask_i, episode_i)
            if success:
                success_counter += 1
            else:
                return success_counter
        return success_counter
    
    def rollout(self, subtask, subtask_i, episode_i, robot_obs=None, scene_obs=None):
        """
        Run the actual rollout on one subtask (which is one natural language instruction).
        """
        planned_actions = []
        if robot_obs is not None and scene_obs is not None:
            self.env.reset({"robot_obs": robot_obs, "scene_obs": scene_obs})
        obs = self.env.get_obs()
        # get lang annotation for subtask
        if self.env.env_settings.diverse_inst:
            lang_annotation = self.val_annotations[episode_i][subtask_i]
        else:
            lang_annotation = self.val_annotations[subtask][0]
        lang_annotation = lang_annotation.split('\n')[0]
        if '\u2019' in lang_annotation:
            lang_annotation.replace('\u2019', '\'')
        self.agent.reset()
        start_info = self.env.get_info()

        for step in range(self.episode_length):
            action = self.agent.step({"observation": obs, "goal": lang_annotation, "timestep": step})

            if len(planned_actions) == 0:
                if action.shape == (7,):
                    planned_actions.append(action)
                else:
                    planned_actions.extend([action[i] for i in range(action.shape[0])])
            action = planned_actions.pop(0)
            obs, _, _, current_info = self.env.step(action)
            if step == 0:
                collect_plan(self.agent, self.plans, subtask)
            # check if current step solves a task
            current_task_info = self.task_oracle.get_task_info_for_set(start_info, current_info, {subtask})
            if len(current_task_info) > 0:
                return True
        return False