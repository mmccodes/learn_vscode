from grmanipulation.env.base import EnvWrapper
from grmanipulation.configs.env.env_cfg import EnvCfg
from grmanipulation.configs.env.calvin_env import CalvinEnvSettings
from omegaconf import OmegaConf
import hydra
from typing import Optional


@EnvWrapper.register("calvin")
class CalvinEnv(EnvWrapper):
    def __init__(self, config: EnvCfg):
        super().__init__(config)
        self.env_settings = CalvinEnvSettings(**config.env_settings)
        print(f"calvin env settings: {self.env_settings}")

        show_gui = self.env_settings.show_gui
        render_conf = OmegaConf.load(self.env_settings.config_path)
        if not hydra.core.global_hydra.GlobalHydra.instance().is_initialized():
            hydra.initialize(".")
        self.env = hydra.utils.instantiate(render_conf.env, show_gui=show_gui, use_vr=False, use_scene_info=True)
    
    def reset(self, seed: Optional[int] = None, options: Optional[dict] = None):
        obs = self.env.reset(robot_obs=options.get("robot_obs", None), scene_obs=options.get("scene_obs", None))
        return obs
    
    def get_obs(self):
        return self.env.get_obs()
    
    def get_info(self):
        return self.env.get_info()
    
    def step(self, action):
        return self.env.step(action)