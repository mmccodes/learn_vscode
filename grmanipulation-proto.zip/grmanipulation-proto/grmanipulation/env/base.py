from typing import Dict, Any
from grmanipulation.configs.env.env_cfg import EnvCfg


class EnvWrapper:
    """
    Base class of all environments.
    """

    envs = {}

    def __init__(self, config: EnvCfg):
        self.config = config

    def reset(self):
        raise NotImplementedError

    def step(self):
        raise NotImplementedError

    def close(self):
        raise NotImplementedError
    
    def render(self):
        raise NotImplementedError
    
    def get_obs(self):
        raise NotImplementedError
    
    def get_info(self):
        raise NotImplementedError

    @classmethod
    def register(cls, env_type: str):
        """
        Register a env class.
        """
        def decorator(env_class):
            cls.envs[env_type] = env_class

        return decorator
    
    @classmethod
    def init(cls, config: EnvCfg):
        """
        Init a env instance from a config.
        """
        return cls.envs[config.env_type](config)