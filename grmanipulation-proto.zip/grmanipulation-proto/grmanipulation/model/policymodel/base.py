from typing import Dict, Any
from torch import nn
from grmanipulation.configs import ModelCfg

class BasePolicyModel(nn.Module):
    policy_model_classes: Dict[str, nn.Module] = {}

    def __init__(self, config: ModelCfg, **kwargs):
        super().__init__()
        self.config = config

    def forward(self, *args, **kwargs):
        raise NotImplementedError("Forward method not implemented.")
    
    def calc_loss(self, *args, **kwargs):
        """
        Calculate the loss.
        """
        raise NotImplementedError("Calc loss method not implemented.")
    

    @classmethod
    def register(cls, type: str):
        """
        Register a model class.
        """
        def decorator(model_class):
            cls.policy_model_classes[type] = model_class

        return decorator
    
    @classmethod
    def init(cls, config: ModelCfg):
        """
        Init a model instance from a config.
        """
        model: nn.Module = cls.policy_model_classes[config.type](config)
        return model
