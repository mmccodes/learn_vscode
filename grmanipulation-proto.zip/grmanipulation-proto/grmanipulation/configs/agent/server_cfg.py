from pydantic import BaseModel
from typing import Dict, Any


class ServerCfg(BaseModel):
    server_host: str = "localhost"
    server_port: int = 5000
    device: str = "cuda"