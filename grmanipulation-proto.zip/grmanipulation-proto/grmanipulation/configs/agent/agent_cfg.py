from pydantic import BaseModel
from grmanipulation.configs.model.model_cfg import ModelCfg
from grmanipulation.configs.agent.server_cfg import ServerCfg

class AgentCfg(BaseModel):
    agent_type: str
    model_cfg: ModelCfg = None
    server_cfg: ServerCfg = None
