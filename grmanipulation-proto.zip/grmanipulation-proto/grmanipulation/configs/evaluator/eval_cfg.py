from pydantic import BaseModel
from typing import Dict, Any, Optional
from grmanipulation.configs.agent.agent_cfg import AgentCfg
from grmanipulation.configs.env.env_cfg import EnvCfg
from grmanipulation.configs.evaluator.task_cfg import TaskCfg   


class EvalCfg(BaseModel):
    eval_type: str
    agent: AgentCfg
    env: EnvCfg
    task: Optional[TaskCfg] = None
    eval_settings: Optional[Dict[str, Any]] = {}