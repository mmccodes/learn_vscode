from pydantic import BaseModel
from typing import Dict, Any, Optional


class TaskCfg(BaseModel):
    task_name: str = None
    task_settings: Optional[Dict[str, Any]] = {}