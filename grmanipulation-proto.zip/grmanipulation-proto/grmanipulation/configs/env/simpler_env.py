from pydantic import BaseModel, Field, validator
from typing import Optional, Tuple
from pathlib import Path
from simpler_env import ENVIRONMENTS, ENVIRONMENT_MAP


class SimplerEnvSettings(BaseModel):
    policy_setup: str = Field(default="google_robot", description="Policy model setup")
    task_name: str = Field(default="google_robot_pick_coke_can", description="Task name")
    env_name: str = Field(default="GraspSingleOpenedCokeCanInScene-v0", description="Environment name")
    additional_env_save_tags: Optional[str] = Field(default=None, description="Additional tags to save the environment eval results")
    scene_name: Optional[str] = Field(default=None, description="Scene name")
    enable_raytracing: Optional[bool] = Field(default=False, description="Enable raytracing")
    robot: Optional[str] = Field(default="google_robot_static", description="Robot name")
    obs_camera_name: Optional[str] = Field(default=None, description="Obtain image observation from this camera for policy input. None = default")
    action_scale: Optional[float] = Field(default=1.0, description="Action scale")
    control_freq: Optional[int] = Field(default=3, description="Control frequency")
    sim_freq: Optional[int] = Field(default=513, description="Simulation frequency")
    max_episode_steps: Optional[int] = Field(default=80, description="Maximum episode steps")
    rgb_overlay_path: Optional[str] = Field(default=None, description="RGB overlay image path")
    robot_init_x_range: Optional[Tuple[float, float, float]] = Field(default = [0.35, 0.35, 1], description="Robot initial X range, it means [xmin, xmax, num]")
    robot_init_y_range: Optional[Tuple[float, float, float]] = Field(default = [0.20, 0.20, 1], description="Robot initial Y range, it means [ymin, ymax, num]")
    robot_init_rot_quat_center: Optional[Tuple[float, float, float, float]] = Field(default = [1, 0, 0, 0], description="Robot initial quaternion, it means [x, y, z, w]")
    robot_init_rot_rpy_range: Optional[Tuple[float, float, float, float, float, float, float, float, float]] = Field(default = [0, 0, 1, 0, 0, 1, 0, 0, 1], description="Robot initial RPY(roll, pitch, yaw) range, it means [rmin, rmax, rnum, pmin, pmax, pnum, ymin, ymax, ynum]")
    obj_variation_mode: Optional[str] = Field(default="xy", description="Whether to vary the xy position of a single object, or to vary predetermined episodes")
    obj_episode_range: Optional[Tuple[int, int]] = Field(default = [0, 60], description="Object episode range, it means [start, end]")
    obj_init_x_range: Optional[Tuple[float, float, float]] = Field(default = [-0.35, -0.12, 5], description="Object initial X range, it means [xmin, xmax, num]")
    obj_init_y_range: Optional[Tuple[float, float, float]] = Field(default = [-0.02, 0.42, 5], description="Object initial Y range, it means [ymin, ymax, num]")
    additional_env_build_kwargs: Optional[dict] = Field(default=None, description="Additional environment build kwargs")
    logging_dir: Optional[str] = Field(default = Path(__file__).parents[3] / "logs" / "eval" / "simpler", description="Logging directory")
    tf_memory_limit: Optional[int] = Field(default=3072, description="Tensorflow memory limit")
    octo_init_rng: Optional[int] = Field(default=0, description="Octo initialization random seed")
    
    @validator('policy_setup')
    def check_policy_setup(cls, v):
        if v not in ["widowx_bridge", "google_robot"]:
            raise ValueError(f"Invalid policy setup type: {v}")
        return v
    
    @validator('task_name')
    def check_task_name(cls, v):
        if v not in ENVIRONMENTS:
            raise ValueError(f"Invalid task name: {v}")
        return v
    
    @validator('env_name')
    def check_env_name(cls, v):
        if v not in set([env_name for env_name, _ in ENVIRONMENT_MAP.values()]):
            raise ValueError(f"Invalid environment name: {v}")
        env_name, _ = ENVIRONMENT_MAP[cls.task_name]
        if v != env_name:
            raise ValueError(f"Task_name {cls.task_name} and env_name {v} mismatch")
        return v
    
    @validator('robot')
    def check_robot(cls, v):
        if v not in ["google_robot_static", "widowx"]:
            raise ValueError(f"Invalid robot name: {v}")
        return v
    
    @validator('rgb_overlay_path')
    def check_rgb_overlay_path(cls, v):
        if v is not None and not Path(v).exists():
            raise ValueError(f"RGB overlay image path does not exist: {v}")
        return v
    
    @validator('obj_variation_mode')
    def check_obj_variation_mode(cls, v):
        if v not in ["xy", "episode"]:
            raise ValueError(f"Invalid object variation mode: {v}")
        return v
    
    @validator('logging_dir')
    def check_logging_dir(cls, v):
        if v is not None and not Path(v).exists():
            raise ValueError(f"Logging directory does not exist: {v}")
        return v