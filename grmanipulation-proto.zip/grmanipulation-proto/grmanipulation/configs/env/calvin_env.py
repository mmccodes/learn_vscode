from pydantic import BaseModel, Field, validator
from typing import Optional
from pathlib import Path


class CalvinEnvSettings(BaseModel):
    config_path: Optional[str] = Field(default=f"{Path(__file__).parents[2]}/benchmarks/utils/calvin/merged_config.yaml", description="Path to the calvin env config file")
    show_gui: Optional[bool] = Field(default=False, description="Whether to show the gui")
    diverse_inst: Optional[bool] = Field(default=False, description="Whether to use diverse instances")
    num_sequences: Optional[int] = Field(default=1000, description="Number of eval sequences")
    episode_length: Optional[int] = Field(default=360, description="Episode length")
    debug: Optional[bool] = Field(default=False, description="Whether to use debug mode")
    reset: Optional[bool] = Field(default=False, description="Whether to reset the environment")

    @validator('config_path')
    def check_config_path(cls, v):
        if v is not None and not Path(v).exists():
            raise ValueError(f"Invalid config path: {v}")
        return v