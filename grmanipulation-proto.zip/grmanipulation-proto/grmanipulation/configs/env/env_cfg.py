from pydantic import BaseModel, validator, Field
from typing import Dict, Any


class EnvCfg(BaseModel):
    env_type: str
    env_settings: Dict[str, Any] = Field(default={}, description="Environment custom settings based on the specific environment cfg")

    @validator('env_type')
    def check_env_type(cls, v):
        if v not in ["simpler", "calvin", "genmanip"]:
            raise ValueError(f"Invalid environment type: {v}")
        return v