from pydantic import BaseModel
from typing import Dict, Any, Optional


class ModelCfg(BaseModel):
    model_type: str
    policy_name: str
    ckpt_path: str
    model_settings: Optional[Dict[str, Any]] = {}
